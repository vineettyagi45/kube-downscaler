__version__ = "2019.1.1dev0"  # will be replaced during build
